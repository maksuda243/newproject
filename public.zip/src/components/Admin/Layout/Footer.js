import React from "react";
import './layout.css';

function Footer() {
    return (
      <footer className="dashboard-footer">
       e-commerce site with React $Copy; Maksuda Akter
    </footer>
    ) 
}
export default Footer;