 module.exports = global.config = {
    apiUrl: "http://localhost/e-commerce/"
}; 